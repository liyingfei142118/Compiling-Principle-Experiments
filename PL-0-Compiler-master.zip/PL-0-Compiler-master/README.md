# PL/0 Compiler

### 说明
* testPL0文件夹中是测试文件,MyCompiler文件夹中是IDEA工程文件
* 开发环境为Windows10，开发工具为IDEA
* 详细说明见：[PL/0语言编译器的设计与实现](http://www.cnblogs.com/hf-z/p/5542070.html)
